#!/bin/bash
DATE=`date +"%y%m%d_%H%M%S"`
cd /opt/products/dstar/dstar_gw/dsgwd
if [[ -z $1 ]]	# no param
then
	echo "normal mode start" 
	./dsgwd
else
	echo "debug mode start" 
	mv log log.$DATE
	./dsgwd_dbg |tee log
fi
