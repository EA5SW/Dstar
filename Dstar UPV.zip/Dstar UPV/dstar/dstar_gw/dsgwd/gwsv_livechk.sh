#!/bin/bash
echo "is live dsgwd"
for q in `ps -ef | grep dsgwd | grep -v grep | grep -v '\/dsgwd\/' | grep -v vi | awk '{ print $2 }'`
do
	echo "live: id=$q"
	exit 0;
done
echo "not live"
exit 1;
