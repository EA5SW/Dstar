#!/bin/bash
/opt/products/dstar/dstar_gw/dsgwd/gwsv_livechk.sh
if [[ $? == 1 ]]
then
	# gwsv not live
	#echo "304" > $2
	#echo "gwsv not live"
	nohup /opt/products/dstar/dstar_gw/dsgwd/gwstart.sh &
fi
