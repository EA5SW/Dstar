if [ `ps -e | grep dsipsvd | grep -v grep | wc -l` != 0 ]; then

	printf '\ndsipsvd is running...'
else
	printf '\ndsipsvd is stopped'
fi

if [ `ps -e | grep dsgwd | grep -v grep | wc -l` != 0 ]; then
	printf '\ndsgwd is running...'
else
	printf '\ndsgwd is stopped'
fi

printf '\n'

exit 0
