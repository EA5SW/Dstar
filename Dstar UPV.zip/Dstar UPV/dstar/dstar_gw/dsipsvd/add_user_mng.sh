java -classpath %CLASSPATH%:.:/usr/share/java/postgresql94-jdbc.jar:/usr/share/java/log4j.jar:/var/lib/tomcat/webapps/D-STAR/WEB-INF/classes jp.co.icom.dstar.com.adminutl.AdminUserCreator
