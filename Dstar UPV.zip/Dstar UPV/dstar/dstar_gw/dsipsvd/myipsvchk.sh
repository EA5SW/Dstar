#!/bin/bash -l
/opt/products/dstar/dstar_gw/dsipsvd/ipsv_livechk.sh
if [[ $? == 1 ]]
then
	# ipsv not live
	#echo "304" > $2
	#echo "ipsv not live"
	nohup /opt/products/dstar/dstar_gw/dsipsvd/ipstart.sh &
fi
