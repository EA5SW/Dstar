#!/bin/bash
CONF_FILE=/opt/products/dstar/dstar_gw/dsipsvd/dsipsvd.conf
DAYBEFORE=1
# 0x0d must be removed by tr command.
SERCH_DIR=`grep ^DB_COMMAND_PATH $CONF_FILE | awk -F= '{print $2}' | tr -d '\015'`

#echo "1:$SERCH_DIR"
#echo "DAYBEFORE:$DAYBEFORE"
#date
#echo ""
#echo "> The files created older than the days designated as $DAYBEFORE before this midnight will be displayed. "
#echo "> e.g.) when DAYBEFORE=3, if today is 10/10, then the files created prior to 10/5 will be displayed. "
#echo ""
#echo "serch dir1 : $SERCH_DIR"

# for test
#find $SERCH_DIR -name "*.euc" -exec ls -l {} \;
#find $SERCH_DIR -ctime +$DAYBEFORE -name "*.dat" -exec ls -l {} \;

# for org
find $SERCH_DIR -ctime +$DAYBEFORE -name "*.dat*" -exec rm {} \;

#
# memo
#
#echo "The files created at the days desigrated as $DAYBEFORE before today will be displayed. "
#DAYBEFORE=$((DAYBEFORE + 2))
