#!/bin/bash -l
DATE=`date +"%y%m%d_%H%M%S"`
rm -f /tmp/dsipsvd-cmd*
for q in `ps -ef | grep dbupdate | grep -v grep | awk '{ print $2 }'`
do
	echo $q
	kill -9 $q
done
for q in `ps -ef | grep dbsync | grep -v grep | awk '{ print $2 }'`
do
	echo $q
	kill -9 $q
done
for q in `ps -ef | grep ipchk | grep -v grep | awk '{ print $2 }'`
do
	echo $q
	kill -9 $q
done

cd /opt/products/dstar/dstar_gw/dsipsvd
echo "$1"
if [[ -z $1 ]]	# no param
then
	echo "normal mode start" 
	./dsipsvd dsipsvd.conf
else
	echo "debug mode start" 
	mv log log.$DATE
	./dsipsvd_dbg dsipsvd.conf |tee log
fi
