#!/bin/bash
/opt/products/dstar/dstar_gw/dsipsvd/ipsv_livechk.sh
if [[ $? == 1 ]]
then
	# ipsv not live
	#echo "304" > $2
	#echo "ipsv not live"
	exit 0;
fi

time=`expr $RANDOM % 3540`
sleep $time
echo "ipchk" > /tmp/dsipsvd-cmdin
