#!/bin/bash
/opt/products/dstar/dstar_gw/dsipsvd/ipsv_livechk.sh
if [[ $? == 1 ]]
then
	# ipsv not live
	echo "506" > $2
	exit 0;
fi
echo "dbupdate $1 $2" > /tmp/dsipsvd-cmdin
