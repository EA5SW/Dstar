#!/bin/bash
/opt/products/dstar/dstar_gw/dsipsvd/ipsv_livechk.sh
if [[ $? == 1 ]]
then
	echo "ipsv not live"
	#echo "304" > $2
	exit 0;
fi
echo "dbsync $1" > /tmp/dsipsvd-cmdin
