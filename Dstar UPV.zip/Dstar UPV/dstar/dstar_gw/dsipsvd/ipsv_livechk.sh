#!/bin/bash
echo "is live dsipsvd"
for q in `ps -ef | grep dsipsvd | grep -v grep | grep -v '\/dsipsvd\/' | grep -v vi | awk '{ print $2 }'`
do
	echo "live: id=$q"
	exit 0;
done
echo "not live"
exit 1;
